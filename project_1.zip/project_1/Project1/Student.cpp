#include "Student.h"

// default constructor


// setStudentInfo


// getID


// getNumberOfCourses


// getCreditsEnrolled


// isTuitionPaid


// isEnrolledInCourse


// getGpa


// billingAmount


// printStudentInfo


// printStudentInfo (overloaded)


// getCoursesEnrolled


// destructor
